# DataShare

plateforme de transfert sécurisé de fichiers

## Stack

- Front-end : React / Vite
- Back-end : .NET 8
- Base de données : PostgreSQL
- Stockage : fichiers local
- Authentification : JWT toekn

## Fonctionnalités couvertes

- Création de compte
- Connexion
- Upload d'un fichier par un utilisateur connecté
- Génération d'un lien de téléchargement temporaire
- Consultation de l'historique des fichiers
- Suppression d'un fichier
- Téléchargement via lien unique
- Mot de passe optionnel sur le fichier
- Expiration entre 1 et 7 jours

je n'ai pas été à la fin totale du rpojet avec les parties optionnelles car manque de temps et retard.

## Lancer bdd PostgreSQL

À la racine du pojet :

```bash
docker compose up -d postgres
```

## Lancer le back-end

```bash
cd backend/DataShare.Api
dotnet restore
dotnet tool install --global dotnet-ef
dotnet ef migrations add InitialCreate
dotnet ef database update
dotnet run
```

## Lancer le front-end

```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

## Tests

Back-end :

```bash
cd backend
 dotnet test
```

Front-end :

```bash
cd frontend
npm run build
```

L'IA a été utilisée principalement pour le frontend, la génération du .gitignore, la correction de certains tests ainsi que de certains bugs.