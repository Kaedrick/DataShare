# Base de données

Le projet utilise PostgreSQL. Le plus simple pour tester est Docker :

```bash
docker compose up -d postgres
```

La chaîne de connexion par défaut est déjà dans `backend/DataShare.Api/appsettings.json`.

Ensuite, depuis `backend/DataShare.Api` :

```bash
dotnet tool install --global dotnet-ef
dotnet ef migrations add InitialCreate
dotnet ef database update
```

Ces commandes créent les tables `Users` et `StoredFiles`.

Alternative sans migration EF :

```bash
psql -h localhost -U datashare_user -d datashare -f database/init.sql
```
