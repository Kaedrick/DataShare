# Documentation technique DataShare

## Architecture

```txt
React/Vite  ->  ASP.NET Core REST API  ->  PostgreSQL
                         |
                         v
                 Stockage local /uploads
```

## Choix techniques

Le front-end est réalisé avec React, qui fait partie des options autorisées. Il permet de créer rapidement des pages séparées pour l'upload, l'espace personnel, l'authentification et le téléchargement.

Le back-end est réalisé en ASP.NET Core Web API. Ce choix est adapté à une API REST structurée avec authentification JWT, validation des entrées et séparation entre controllers/services/modèles.

PostgreSQL est utilisé pour stocker les utilisateurs et les métadonnées des fichiers. Les fichiers eux-mêmes sont stockés localement pour le MVP, afin d'éviter la complexité d'un stockage cloud.

## Modèle de données

### User

- Id
- Email
- PasswordHash
- CreatedAt

### StoredFile

- Id
- OriginalName
- StoredName
- ContentType
- Size
- RelativePath
- Token
- PasswordHash nullable
- UploadedAt
- ExpiresAt
- UserId

Relation : un utilisateur possède plusieurs fichiers.

## Endpoints principaux

| Méthode | Route | Description | Auth |
|---|---|---|---|
| GET | /api/health | Vérifier l'état de l'API | Non |
| POST | /api/auth/register | Créer un compte | Non |
| POST | /api/auth/login | Se connecter | Non |
| POST | /api/files/upload | Envoyer un fichier | Oui |
| GET | /api/files/me | Voir mes fichiers | Oui |
| DELETE | /api/files/{id} | Supprimer un fichier | Oui |
| GET | /api/download/{token} | Lire les métadonnées du fichier | Non |
| POST | /api/download/{token} | Télécharger le fichier | Non |

## Sécurité

- Mot de passe utilisateur hashé avec BCrypt.
- Authentification par JWT.
- Routes de gestion de fichiers protégées par `[Authorize]`.
- Suppression limitée au propriétaire du fichier.
- Token de téléchargement généré aléatoirement.
- Mot de passe de fichier stocké hashé si renseigné.
- Blocage de quelques extensions dangereuses côté serveur.

## Performance

Le stockage local est suffisant pour le MVP. Pour une version plus sérieuse, il faudrait ajouter :

- stockage S3 ;
- scan antivirus ;
- quotas par utilisateur ;
- pagination de l'historique ;
- tâche automatique de purge des fichiers expirés.
