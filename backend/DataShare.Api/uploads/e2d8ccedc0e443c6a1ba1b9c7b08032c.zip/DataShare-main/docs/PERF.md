# Performance

## Endpoint critique

L'endpoint le plus sensible est :

```txt
POST /api/files/upload
```

Il manipule des fichiers jusqu'à 1 Go et doit être surveillé.

## Test rapide avec k6

Exemple de scénario à compléter avec un vrai fichier de test :

```js
import http from 'k6/http';
import { check } from 'k6';

export default function () {
  const res = http.get('http://localhost:5220/api/health');
  check(res, { 'status 200': r => r.status === 200 });
}
```

## Budget front

- Build Vite sans erreur.
- Pages principales sous 2 secondes en local.
- Bundle à surveiller avec les outils navigateur.

## Métriques à suivre

- Temps de réponse upload/download.
- Taille moyenne des fichiers.
- Nombre d'erreurs 4xx/5xx.
- Espace disque utilisé par `/uploads`.
