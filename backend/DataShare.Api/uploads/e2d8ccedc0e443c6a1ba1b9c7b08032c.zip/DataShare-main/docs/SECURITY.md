# Sécurité

## Mesures en place

- Hash BCrypt pour les mots de passe.
- Authentification JWT.
- Contrôle de propriété avant suppression.
- Token de téléchargement non prédictible.
- Mot de passe de fichier optionnel mais hashé.
- Limite de taille fichier : 1 Go.
- Blocage de quelques extensions exécutables.

## Scan de dépendances

Commandes à exécuter :

```bash
cd frontend
npm audit
```

```bash
cd backend/DataShare.Api
dotnet list package --vulnerable
```

## Points à améliorer

- Ajouter un antivirus sur les fichiers uploadés.
- Déplacer la clé JWT dans une variable d'environnement.
- Ajouter une vraie stratégie de logs sécurité.
- Ajouter un rate limiting sur login et upload.
