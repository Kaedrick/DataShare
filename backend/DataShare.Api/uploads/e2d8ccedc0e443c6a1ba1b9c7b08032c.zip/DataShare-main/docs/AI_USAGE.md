# Utilisation de l'IA dans le projet

L'IA a été utilisée comme assistant de cadrage et de développement pour accélérer certaines parties du prototype.

## Travaux assistés par IA

- Aide à la structuration initiale du projet front/back.
- Proposition d'une architecture simple adaptée au MVP.
- Aide à la rédaction de certains fichiers de documentation.
- Suggestions sur la séparation entre controllers, services, modèles et DTO.
- Relecture de la logique d'authentification et de gestion des fichiers.

## Supervision humaine

Les choix retenus ont été revus avant intégration :

- limitation du périmètre au MVP obligatoire ;
- choix de PostgreSQL et stockage local pour éviter une complexité inutile ;
- exclusion des tags et de l'upload anonyme, car ce sont des fonctionnalités optionnelles ;
- vérification que les règles principales des user stories étaient couvertes ;
- ajustement de l'interface pour rester proche des maquettes fournies.

## Limites

Le projet reste un prototype. Certaines améliorations sont prévues mais non priorisées dans cette version :

- couverture de tests plus complète ;
- interface d'administration ;
- nettoyage automatique réel via tâche planifiée ;
- stockage cloud S3 ;
- suivi plus complet des logs et métriques.

L'objectif était d'obtenir une base fonctionnelle, compréhensible et maintenable, pas de livrer une plateforme prête pour la production.
