# Plan de tests

## Objectif

Vérifier les parcours critiques du MVP : compte, connexion, upload, historique, suppression et téléchargement.

| Fonctionnalité | Type de test | Critère d'acceptation |
|---|---|---|
| Création de compte | API / manuel | Email unique, mot de passe hashé |
| Connexion | API / manuel | Retourne un JWT valide |
| Upload | API / manuel | Crée un fichier et un lien |
| Historique | API / manuel | Affiche uniquement les fichiers de l'utilisateur |
| Suppression | API / manuel | Supprime fichier et métadonnées |
| Téléchargement | API / manuel | Télécharge si lien valide et non expiré |

## Commandes

```bash
cd backend
dotnet test
```

```bash
cd frontend
npm run build
```

## Couverture

Objectif indicatif : 70 %. Dans cette version, seul un test de santé API est fourni comme base. Les tests complets sont à compléter avant soutenance.
