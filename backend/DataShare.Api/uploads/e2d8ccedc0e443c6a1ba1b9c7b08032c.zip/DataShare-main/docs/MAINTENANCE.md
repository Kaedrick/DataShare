# Maintenance

## Mise à jour des dépendances

Fréquence conseillée : une fois par mois ou avant chaque livraison importante.

Commandes :

```bash
cd frontend
npm outdated
npm update
```

```bash
cd backend/DataShare.Api
dotnet list package --outdated
```

## Risques

- Changement de version majeure React/Vite.
- Changement de version Entity Framework.
- Incompatibilité avec le provider PostgreSQL.
- Régression sur l'authentification JWT.

## Sauvegarde

Avant une mise à jour importante :

- sauvegarder PostgreSQL ;
- sauvegarder le dossier `uploads` ;
- lancer les tests ;
- vérifier un parcours complet : inscription, login, upload, téléchargement.
